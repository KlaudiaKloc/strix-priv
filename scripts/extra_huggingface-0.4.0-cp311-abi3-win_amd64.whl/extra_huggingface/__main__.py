"""Allow `python -m extra_huggingface` to start the agent."""

from extra_huggingface.cli import main

main()
